describe('ToggleComponent', () => {
    it('Should be true', () => {
       const test = true;
       expect(test).toBe(true);
    });
 });